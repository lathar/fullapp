import { Component, OnInit } from '@angular/core';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { ContentServiceService } from './services/content-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  content: any = {};
  events: any = {};
  selectedEventIndex: number = 0;
  selectedNav:number;
  constructor(private contentService: ContentServiceService) { }
  ngOnInit() {
    forkJoin(this.contentService.getJSON(), this.contentService.getEvents()).subscribe(([staticData, events]) => {
      this.content = staticData;
      this.events = events;
      console.log(this.events);
    });
  }
  setIndex(selectedTab:number) {
    this.selectedEventIndex = selectedTab;
  }
  setNavClass(selectedTab:number) {
    this.selectedNav = selectedTab;
  }
}
