import { Injectable } from '@angular/core';
import { Http, Headers, Response, Jsonp, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()
export class ContentServiceService {

  constructor(private http: Http) {
    
  }

  public getJSON(): Observable<any> {    
    return this.http.get('../assets/data/staticData.json').map(res => res.json());
  }
  public getEvents():Observable<Response> {
    return this.http.get('../assets/data/events.json').map(res => res.json());
  }
}
